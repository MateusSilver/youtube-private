# Projeto Youtube Private
Com site favorito sendo o **youtube**, foi escolhido a criação de uma extensão do google chrome com os seguintes requesitos:
* A extensão deve permitir censurar thumbnails de videos do youtube no feed inicial
* A extensao deve permitir censurar o nome de videos do youtube no feed inicial
* A extensao deve permitir censurar nome de canais no feed inicial
## Organização
```
L_ .index.html
L_ .style.css
L_ scripts
 L__ blurChannels.js
 L__ blurThumbnails.js
 L__ blurTitles.js
L_ manifest.json
L_ package.json
L_ .hintrc
L_ README.md
```

